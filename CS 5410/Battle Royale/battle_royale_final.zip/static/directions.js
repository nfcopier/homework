export default {
    LEFT: 1,
    RIGHT: 2,
    TOP: 4,
    BOTTOM: 8
}