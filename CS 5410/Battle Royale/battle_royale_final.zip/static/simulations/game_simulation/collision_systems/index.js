import collisionDetector from "./collision_detector.js"

export default function (
) {

    const CollisionDetector = collisionDetector();

    return {
    };

}
