export default {
    EASY: 0,
    NORMAL: 1,
    HARD: 2
}